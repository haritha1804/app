let admins = [
    { username: "admin", password: "admin" }
];

let patients = [
    { username: "patient1", password: "pass1", details: { uid:"1", name: "John Doe", age: 30, email: "john.doe@example.com",status:"bp low"} },
    { username: "patient2", password: "pass2", details: { uid :"2",name: "Jane Smith", age: 25, email: "jane.smith@example.com",status:"high sugar" } }
];

let currentAdmin = null;
let currentPatient = null;

function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    currentAdmin = admins.find(a => a.username === username && a.password === password);
    currentPatient = patients.find(p => p.username === username && p.password === password);

    if (currentAdmin) {
        displayAdminPanel();
    } else if (currentPatient) {
        displayPatientPanel(currentPatient);
    } else {
        alert("Invalid username or password");
    }
}

function displayAdminPanel() {
    document.getElementById("login-form").classList.add("hidden");
    document.getElementById("admin-panel").classList.remove("hidden");
    document.getElementById("patient-panel").classList.add("hidden");
}

function displayPatientPanel(patient) {
    const welcomeUser = document.getElementById("welcome-user");
    const details = document.getElementById("details");

    welcomeUser.textContent = patient.details.name;
    details.innerHTML = `
        <p>uid:${patient.details.uid}</p>
        <p>Name: ${patient.details.name}</p>
        <p>Age: ${patient.details.age}</p>
        <p>Email: ${patient.details.email}</p>
        <p>status: ${patient.details.status}</p>
        
    `;

    document.getElementById("login-form").classList.add("hidden");
    document.getElementById("admin-panel").classList.add("hidden");
    document.getElementById("patient-panel").classList.remove("hidden");
}

function viewPatients() {
    let patientList = "<h3>Patient List</h3>";
    patients.forEach((patient, index) => {
        patientList += `
            <div>
                <p>uid:${patient.details.uid}</p>
                <p>Name: ${patient.details.name}</p>
                <p>Age: ${patient.details.age}</p>
                <p>Email: ${patient.details.email}</p>
                <p>status: ${patient.details.status}</p>
                <button onclick="editPatient(${index})">Edit</button>
            </div>
        `;
    });
    patientList += '<button onclick="addPatient()">Add New Patient</button>';
    patientList += '<button onclick="logout()">Logout</button>';
    document.getElementById("admin-panel").innerHTML = patientList;
}

function editPatient(index) {
    const patient = patients[index];
    const uid=prompt("Enter the uid:",patient.details.uid);
    const newName = prompt("Enter new name:", patient.details.name);
    const newAge = prompt("Enter new age:", patient.details.age);
    const newEmail = prompt("Enter new email:", patient.details.email);
    const newstatus = prompt("Enter new status:", patient.details.status);

    if (newName && newAge && newEmail && newuid && newstatus) {
        patient.details.uid=newuid;
        patient.details.name = newName;
        patient.details.age = newAge;
        patient.details.email = newEmail;
        patient.details.status = newstatus;
        alert("Patient details updated successfully!");
        viewPatients();
    } else {
        alert("Invalid input!");
    }
}

function addPatient() {
    const username = prompt("Enter username:");
    const password = prompt("Enter password:");
    const uid=prompt("enter uid number");
    const name = prompt("Enter name:");
    const age = prompt("Enter age:");
    const email = prompt("Enter email:");
    const  status= prompt("Enter new status:");

    if (username && password && uid && status && name && age && email) {
        patients.push({
            username,
            password,
            details: {
                uid,
                name,
                age,
                email,
            }
        });
        alert("Patient added successfully!");
        viewPatients();
    } else {
        alert("Invalid input!");
    }
}

function goBack(panel) {
    if (panel === "admin-panel") {
        document.getElementById("admin-panel").classList.add("hidden");
        document.getElementById("login-form").classList.remove("hidden");
    } else if (panel === "patient-panel") {
        document.getElementById("patient-panel").classList.add("hidden");
        document.getElementById("login-form").classList.remove("hidden");
    }
}

function logout() {
    currentAdmin = null;
    currentPatient = null;
    document.getElementById("login-form").classList.remove("hidden");
    document.getElementById("admin-panel").classList.add("hidden");
    document.getElementById("patient-panel").classList.add("hidden");
}
